import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { ProgressCircle } from 'react-native-svg-charts';
import { LineChart } from 'react-native-chart-kit';

const StepsScreen = () => {
  const steps = 11857;
  const goal = 18000;
  const kcal = 850;
  const distance = 5;
  const duration = 120;
  const progress = steps / goal;

  return (
    <View style={styles.container}>

      <Text style={styles.subTitle}>You have achieved <Text style={styles.highlight}>{Math.round(progress * 100)}%</Text> of your goal today</Text>
      
      <View style={styles.progressCircleContainer}>
        <ProgressCircle
          style={styles.progressCircle}
          progress={progress}
          progressColor={'#00b0ff'}
          backgroundColor={'#e0e0e0'}
        />
        <View style={styles.circleContent}>
          <Text style={styles.stepCount}>{steps}</Text>
          <Text style={styles.stepGoal}>Steps out of {goal / 1000}k</Text>
        </View>
      </View>

      <View style={styles.metrics}>
        <View style={styles.metric}>
          <ProgressCircle
            style={styles.metricCircle}
            progress={0.7} // Giả sử 70% cho kcal
            progressColor={'#ff7043'}
            backgroundColor={'#f5f5f5'}
          />
          <View style={styles.circleContentSmall}>
            <Text style={styles.metricValue}>{kcal}</Text>
            <Text style={styles.metricLabel}>kcal</Text>
          </View>
        </View>
        
        <View style={styles.metric}>
          <ProgressCircle
            style={styles.metricCircle}
            progress={0.5} // Giả sử 50% cho km
            progressColor={'#66bb6a'}
            backgroundColor={'#f5f5f5'}
          />
          <View style={styles.circleContentSmall}>
            <Text style={styles.metricValue}>{distance}</Text>
            <Text style={styles.metricLabel}>km</Text>
          </View>
        </View>
        
        <View style={styles.metric}>
          <ProgressCircle
            style={styles.metricCircle}
            progress={0.8} // Giả sử 80% cho min
            progressColor={'#42a5f5'}
            backgroundColor={'#f5f5f5'}
          />
          <View style={styles.circleContentSmall}>
            <Text style={styles.metricValue}>{duration}</Text>
            <Text style={styles.metricLabel}>min</Text>
          </View>
        </View>
      </View>

      <View style={styles.chartContainer}>
  <Text style={styles.chartTitle}>Weekly</Text>
  <LineChart
    data={{
      labels: ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"],
      datasets: [
        {
          data: [3000, 7000, 5000, 9000, 12000, 8000, 11000]
        }
      ]
    }}
    width={Dimensions.get('window').width - 60}  // Thu nhỏ chiều rộng
    height={180}  // Thu nhỏ chiều cao
    yAxisSuffix="k"
    yAxisInterval={1}
    chartConfig={{
      backgroundColor: "#e8f5e9",
      backgroundGradientFrom: "#e8f5e9",
      backgroundGradientTo: "#4caf50",
      decimalPlaces: 0,
      color: (opacity = 1) => `rgba(0, 150, 136, ${opacity})`,
      labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
      style: {
        borderRadius: 16
      }
    }}
    style={{
      marginVertical: 8,
      borderRadius: 16
    }}
  />
</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff'
  },
  subTitle: {
    fontSize: 16,
    textAlign: 'center',
    color: '#888',
    marginBottom: 20
  },
  highlight: {
    color: '#00b0ff',
    fontWeight: 'bold'
  },
  progressCircleContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20
  },
  progressCircle: {
    width: 160,  // Thu nhỏ kích thước vòng tròn lớn
    height: 160
  },
  circleContent: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    top: 50,  // Căn chỉnh lại vị trí của nội dung
  },
  stepCount: {
    fontSize: 24,  // Giảm kích thước chữ cho phù hợp
    fontWeight: 'bold',
    color: '#00b0ff'
  },
  stepGoal: {
    fontSize: 12,
    color: '#888'
  },
  metrics: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginVertical: 10
  },
  metric: {
    alignItems: 'center',
    width: 60,  // Thu nhỏ kích thước của metric
    height: 60
  },
  metricCircle: {
    width: 60,  // Thu nhỏ kích thước vòng tròn nhỏ
    height: 60
  },
  circleContentSmall: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    top: 18,  // Căn chỉnh lại nội dung ở giữa vòng tròn nhỏ
  },
  metricValue: {
    fontSize: 14,  // Giảm kích thước chữ cho phù hợp
    fontWeight: 'bold',
    color: '#444'
  },
  metricLabel: {
    fontSize: 10,
    color: '#888'
  },
  chartContainer: {
    width: '100%',
    paddingHorizontal: 5
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10
  }
});

export default StepsScreen;
