import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './HomeScreen';
import StepsScreen from './StepsScreen';
import SleepScreen from './SleepScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Home' }} />
        <Stack.Screen 
          name="Steps" 
          component={StepsScreen} 
          options={{ 
            title: 'Steps',
            headerTitleAlign: 'center',  // Căn giữa tiêu đề của màn hình Steps
          }} 
        />
        <Stack.Screen name="Sleep" component={SleepScreen} options={{ title: 'Sleep' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
