import React from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { LineChart } from 'react-native-chart-kit';

const SleepScreen = () => {
  const sleepData = [7, 6.5, 7.5, 8, 6, 6.5, 7.5]; // Dữ liệu ngủ theo từng ngày trong tuần
  const sleepRate = 82; // Tỷ lệ giấc ngủ
  const deepSleep = '1h 3min'; // Thời gian ngủ sâu
  const avgSleepTime = '7h 31min'; // Thời gian ngủ trung bình trong ngày

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Sleep</Text>
      <Text style={styles.averageSleep}>
        Your average time of sleep a day is {avgSleepTime}
      </Text>
      
      <View style={styles.chartContainer}>
        <LineChart
          data={{
            labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
            datasets: [
              {
                data: sleepData
              }
            ]
          }}
          width={Dimensions.get('window').width - 40}
          height={220}
          chartConfig={{
            backgroundColor: "#e8f5e9",
            backgroundGradientFrom: "#e8f5e9",
            backgroundGradientTo: "#4caf50",
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(0, 150, 136, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            style: {
              borderRadius: 16
            }
          }}
          style={styles.chart}
        />
      </View>

      <View style={styles.infoContainer}>
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Sleep rate</Text>
          <Text style={styles.infoValue}>{sleepRate}%</Text>
        </View>
        
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Deepsleep</Text>
          <Text style={styles.infoValue}>{deepSleep}</Text>
        </View>
      </View>

      <View style={styles.scheduleContainer}>
        <Text style={styles.scheduleTitle}>Set your schedule</Text>
        <View style={styles.scheduleButtons}>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>Bedtime 22:00 pm</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>Wake up 07:30 am</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00b0ff',
    marginBottom: 20,
  },
  averageSleep: {
    fontSize: 18,
    color: '#888',
    textAlign: 'center',
    marginBottom: 30,
  },
  chartContainer: {
    marginBottom: 20,
  },
  chart: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 30,
  },
  infoBox: {
    alignItems: 'center',
    width: '40%',
  },
  infoTitle: {
    fontSize: 16,
    color: '#888',
  },
  infoValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00b0ff',
  },
  scheduleContainer: {
    width: '100%',
    alignItems: 'center',
  },
  scheduleTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00b0ff',
    marginBottom: 20,
  },
  scheduleButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  button: {
    backgroundColor: '#ff7043',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    margin: 5,
  },
  buttonText: {
    fontSize: 14,
    color: '#fff',
    textAlign: 'center',
  },
});

export default SleepScreen;
