import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const NextScreen = ({ navigation }) => {
  return (
    <ScrollView style={styles.container} >
      {/* Header */}
      <View style={styles.head}>
        <Image source={require('./Image/A1.jpg')} style={styles.avatar} />
        <Image source={require('./Image/logo.svg')} style={styles.logo} />
      </View>
      <View style={styles.header}>
        <View>
          <View style={styles.sun}>
            <Ionicons name="sunny" style={styles.sunny}/>
            <Text style={styles.date}> TUES 11 JUL</Text>
          </View>
          <Text style={styles.title}>Overview</Text>
        </View>
        <TouchableOpacity style={styles.allDataButton}>
          <Ionicons name="rocket-outline" style={styles.data}/>
          <Text style={styles.data}>All data</Text>
        </TouchableOpacity>
      </View>

      {/* Health Score */}
      <View style={styles.healthScoreContainer}>
        <View style={styles.healthScoreBox}>
          <View style={styles.circle}>
            <View>
              <Text style={styles.sectionTitle}>Health Score</Text>
              <Text style={styles.healthScoreDescription}>
                Based on your overview health {'\n'}tracking, your score is 78 and {'\n'}consider good..
              </Text>
              <Text style={styles.linkText}>Tell me more ></Text>
            </View>
            <Text style={styles.healthScoreText}>78</Text>
          </View>
        </View>
      </View>

      {/* Highlights */}
      <View style={styles.highlightsContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Highlights</Text>
          <TouchableOpacity onPress={() => navigation.navigate('AllHealthData')}>
            <Text style={styles.linkText}>View more ></Text>
          </TouchableOpacity>
        </View>
        <View style={styles.highlightCards}>
  {/* Highlight Cards Here */}
  <View style={styles.highlightCa}>
    <TouchableOpacity 
      style={[styles.highlightCard, { backgroundColor: '#7d83e6' }]} 
      onPress={() => navigation.navigate('Steps')}>
      <View style={styles.walkcont} >
        <Ionicons name= "walk" style={styles.walk} />
      </View>
      <View>
        <Text style={styles.highlightText}>Steps</Text>
        <Text style={styles.highlightValue}>11,857</Text>
        <Text style={styles.updateText}>updated 15 min ago</Text>
      </View>
    </TouchableOpacity>

    <TouchableOpacity 
      style={[styles.highlightCard, { backgroundColor: '#9374d1' }]} 
      onPress={() => navigation.navigate('CycleTracking')}>
      <View style={styles.walkcont} >
        <Ionicons name= "calendar" style={styles.walk} />
      </View>
      <View>
        <Text style={styles.highlightText}>Cycle tracking</Text>
        <View style={styles.hlbox} >
          <Text style={styles.highlightValue}>12</Text>
          <Text style={styles.highlightText}> days before period</Text> 
        </View>
        <Text style={styles.updateText}>updated 30m ago</Text>
      </View>
    </TouchableOpacity>          
  </View>
  
  <View style={styles.highlightCa}>
    <TouchableOpacity 
      style={[styles.highlightCard, { backgroundColor: '#2b5c91' }]} 
      onPress={() => navigation.navigate('Sleep')}>
      <View style={styles.walkcont} >
        <Ionicons name= "bed" style={styles.walk} />
      </View>
      <View>
        <Text style={styles.highlightText}>Sleep</Text>
        <View style={styles.hlbox} >
          <Text style={styles.highlightValue}>7</Text>
          <Text style={styles.highlightText}> h </Text>
          <Text style={styles.highlightValue}>31</Text>
          <Text style={styles.highlightText}> min </Text>
        </View>
        <Text style={styles.updateText}>updated a day ago</Text>  
      </View>
    </TouchableOpacity>

    <TouchableOpacity 
      style={[styles.highlightCard, { backgroundColor: '#4e9fa2' }]} 
      onPress={() => navigation.navigate('Nutrition')}>
      <View style={styles.walkcont} >
        <Ionicons name= "nutrition" style={styles.walk} />
      </View>
      <View>
        <Text style={styles.highlightText}>Nutrition</Text>
        <View style={styles.hlbox} >
          <Text style={styles.highlightValue}>960</Text>
          <Text style={styles.highlightText}> kcal </Text>
        </View>
        <Text style={styles.updateText}>updated 5 min ago</Text>  
      </View>       
    </TouchableOpacity>
  </View>  
</View>
      </View>

      {/* This Week Report */}
      <View style={styles.weekReportContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>This week report</Text>
          <Text style={styles.linkText}>View more ></Text>
        </View>
        <View style={styles.reportCards}>
          {/* Report Cards Here */}
          <View style={styles.reportCard}>
            <Text style={styles.reportTitle}>👣 Steps</Text>
            <Text style={styles.reportValue}>697,978</Text>
          </View>
          <View style={styles.reportCard}>
            <Text style={styles.reportTitle}>💪 Workout</Text>
            <Text style={styles.reportValue}>6h 45min</Text>
          </View>
          <View style={styles.reportCard}>
            <Text style={styles.reportTitle}>💧 Water</Text>
            <Text style={styles.reportValue}>10,659 ml</Text>
          </View>
          <View style={styles.reportCard}>
            <Text style={styles.reportTitle}>😴 Sleep</Text>
            <Text style={styles.reportValue}>29h 17min</Text>
          </View>
        </View>
      </View>

      {/* Blogs */}
      <View style={styles.blogsContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Blogs</Text>
          <Text style={styles.linkText}>View more ></Text>
        </View>
        <ScrollView 
          horizontal={true}            
          contentContainerStyle={styles.blogCards}>
          {/* Blog Cards Here */}
          <View style={styles.blogCard}>
        <Image source={require('./Image/blog2.jpg')} style={styles.blogImage} />
        <Text style={styles.blogCategory}>Nutrition</Text>
        <Text style={styles.blogTitle}>More about Apples: Benefits, nutrition, and tips</Text>
        <View style={styles.blogre}>
          <View style={styles.blogTag}>
            <Ionicons name="thumbs-up-outline" style={styles.tagtext}/>
            <Text style={styles.tagtext}>78 votes</Text>
          </View>
          <TouchableOpacity>
            <Text style={{color: '#9095A0FF'}}>Tell me more  ></Text>  
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.blogCard}>
        <Image source={require('./Image/blog1.jpg')} style={styles.blogImage} />
        <Text style={styles.blogCategory}>Lifestyle</Text>
        <Text style={styles.blogTitle}>The simple guide to maximizing your health</Text>
        <View style={styles.blogre}>
          <View style={styles.blogTag}>
            <Ionicons name="thumbs-up-outline" style={styles.tagtext}/>
            <Text style={styles.tagtext}>54votes</Text>
          </View>
          <TouchableOpacity>
            <Text style={{color: '#9095A0FF'}}>Tell me more  ></Text>  
          </TouchableOpacity>
        </View>
      </View>
        </ScrollView>
      </View>

      {/* Menu */}
      <View style={styles.menu}>
        {/* Menu Items Here */}
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="menu-outline" style={styles.menuicon1}/>
          <Text style={styles.menuitext1}>Overview</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.menubox} 
          onPress={() => navigation.navigate('Explore')}>
          <Ionicons name="compass-outline" style={styles.menuicon} />
          <Text style={styles.menuitext}>Explore</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox} onPress={() => navigation.navigate('Sharing')}>
          <Ionicons name="share-social-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Sharing</Text>
          </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

// Keep your styles object as it is
const styles = StyleSheet.create({
  container: { 
    paddingHorizontal: 16,
    backgroundColor: '#fafafb',
  },
  head: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between'
  },
  logo: {
    width: 36, 
    height: 36, 
  },
  avatar: {
    width: 44,
    height: 44,
    backgroundColor: '#CACDF8FF',
    borderRadius: 22,
  },
  header: { 
    flexDirection: 'row', 
    justifyContent: 'space-between',
    alignItems: 'center', 
    marginVertical: 10
  },
  sun: {
    flexDirection: 'row',
    alignItems:' center',
  },
  sunny: {
    fontSize: 20,
    marginRight: 3
  },
  date: { 
    fontSize: 14,
    color: '#888' 
  },
  title: { 
    fontSize: 28,
     fontWeight: 'bold'
  },
  allDataButton: { 
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#555ce0',
    padding: 10,
    borderRadius: 20,
    marginTop: 23
  },
  data: {
    color: 'white',
  },
  healthScoreContainer: { 
    marginTop: 20 
  },
  healthScoreBox: { 
    padding: 16, 
    backgroundColor: '#f1f2fc', 
    borderRadius: 8 
  },
  healthScoreText: { 
    fontSize: 36, 
    fontWeight: 'bold', 
    color: 'white',
    backgroundColor: '#ed7e4c',
    padding: 10,
    borderRadius: 20,
    marginBottom: 60,
  },
  healthScoreDescription: { 
    marginBottom: 20,
    marginTop: 10,
  },
  linkText: { 
    color: '#555ce0', 
    fontWeight: '600' 
  },
  highlightsContainer: { 
    marginTop: 20 
  },
  sectionHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center' 
  },
  sectionTitle: { 
    fontSize: 18, 
    fontWeight: 'bold' 
  },
  circle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10
  },  
  highlightCards: { 
    flexWrap: 'wrap', 
    justifyContent: 'space-between', 
    marginTop: 10 
  },
  highlightCa: {
    flexDirection: 'row',
  },
  highlightCard: { 
    width: "48%",
    height: 180, 
    padding: 10, 
    borderRadius: 10, 
    marginBottom: 10,
    marginHorizontal: 5 
  },
  walkcont: {
    flexDirection: 'row',
    justifyContent: 'flex-end'
  },
  walk: {
    color: 'white',
    fontSize: 50,
    marginBottom: 10
  },
  highlightText: { 
    fontSize: 14, 
    color: '#fff',
    fontWeight: '500', 
    marginTop: 5 
  },
  highlightValue: { 
    fontSize: 24, 
    fontWeight: '500', 
    color: '#fff',
    marginTop: 4 
  },
  hlbox: {
    flexDirection: 'row',
    alignItems: 'baseline'
  },
  updateText: { 
    fontSize: 11,
    color: '#fff',
    marginTop: 4 

  },
  weekReportContainer: { 
    marginTop: 20 
  },
  reportCards: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    justifyContent: 'space-between', 
    marginTop: 10 
  },
  reportCard: { 
    width: '48%', 
    padding: 15, 
    backgroundColor: '#ffffff', 
    borderRadius: 10, 
    marginBottom: 10
  },
  reportTitle: { 
    fontSize: 14, 
    color: '#555',
    marginBottom: 10 
  },
  reportValue: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#333'
  },
  blogsContainer: { 
    marginTop: 20 
  },
  blogCards: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginTop: 10 
  },
  blogCard: { 
    width: 272,
    height: 340, 
    marginRight: 16,
    borderRadius: 10, 
    backgroundColor: '#ffffff', 
    padding: 10
  },
  blogImage: { 
    width: 230,
    height: 162,
    marginTop: 10,
    marginHorizontal: 11,
    borderRadius: 16,
    marginBottom: 10
  },
  blogCategory: { 
    color: '#323842FF', 
    fontSize: 12,
    fontWeight: '400', 
    marginTop: 16
  },
  blogre: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  blogTitle: { 
    fontSize: 18, 
    fontWeight: '600', 
    marginTop: 5,
    marginBottom: 20
  },
  blogTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#CACDF8FF',
    borderRadius: 10,
    marginLeft: 11,
    padding: 5
  },
  tagtext: {
    color: '#555ce0',
    marginHorizontal: 2
  },
  menu: {
    marginTop: 31,
    height: 64,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10
  },
  menuicon: {
    fontSize: 24,
  },
  menuicon1: {
    fontSize: 26,
    color: '#555ce0'
  },
  menubox: {
    alignItems: 'center',
    marginHorizontal: 22
  },
  menuitext1:{
    color: '#555ce0',
  },
});

export default NextScreen;
