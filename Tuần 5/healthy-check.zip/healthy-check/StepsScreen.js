import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import Svg, { Circle } from 'react-native-svg';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'; // Make sure this library is installed

const StepsScreen = () => {
  const screenWidth = Dimensions.get('window').width;
  const radius = 75; // Radius of the main progress circle
  const strokeWidth = 10; // Stroke width of the circle
  const size = radius * 2 + strokeWidth; // SVG container size

  const chartConfig = {
    backgroundGradientFrom: '#fff',
    backgroundGradientTo: '#fff',
    color: (opacity = 1) => `rgba(34, 82, 222, ${opacity})`,
    strokeWidth: 2,
    propsForDots: {
      r: '4',
      strokeWidth: '2',
      stroke: '#2252DE',
    },
  };

  // Circular Progress for Metrics
  const renderMetricCircle = (value, maxValue, label) => {
    const percentage = value / maxValue; // Calculate progress as a percentage
    const metricRadius = 40;
    const metricSize = metricRadius * 2 + strokeWidth;

    return (
      <View style={styles.metric}>
        <Svg width={metricSize} height={metricSize} viewBox={`0 0 ${metricSize} ${metricSize}`}>
          {/* Background Circle */}
          <Circle
            cx={metricSize / 2}
            cy={metricSize / 2}
            r={metricRadius}
            stroke="#E6E6E6"
            strokeWidth={strokeWidth}
            fill="none"
          />
          {/* Progress Circle */}
          <Circle
            cx={metricSize / 2}
            cy={metricSize / 2}
            r={metricRadius}
            stroke="#2252DE"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            fill="none"
            strokeDasharray={2 * Math.PI * metricRadius}
            strokeDashoffset={(1 - percentage) * 2 * Math.PI * metricRadius}
          />
        </Svg>
        {/* Metric Value Inside Circle */}
        <View style={styles.metricContent}>
          <Text style={styles.metricValue}>{value}</Text>
          <Text style={styles.metricLabel}>{label}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Achievement Text */}
      <Text style={styles.achievement}>
        You have achieved <Text style={styles.highlight}>80%</Text> of your goal today
      </Text>

      {/* Circular Progress */}
      <View style={styles.progressContainer}>
        <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {/* Background Circle */}
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#E6E6E6"
            strokeWidth={strokeWidth}
            fill="none"
          />
          {/* Progress Circle */}
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#2252DE"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            fill="none"
            strokeDasharray={2 * Math.PI * radius}
            strokeDashoffset={(1 - 0.8) * 2 * Math.PI * radius} // 80% progress
          />
        </Svg>
        {/* Content Inside the Circle */}
        <View style={styles.centerContent}>
          <Icon name="shoe-print" size={24} color="#2252DE" />
          <Text style={styles.stepCount}>11,857</Text>
          <Text style={styles.stepGoal}>Steps out of 18k</Text>
        </View>
      </View>

      {/* Metrics Section */}
      <View style={styles.metricsContainer}>
        {renderMetricCircle(850, 1000, 'kcal')}
        {renderMetricCircle(5, 10, 'km')}
        {renderMetricCircle(120, 180, 'min')}
      </View>

      {/* Chart Section */}
      <View style={styles.chartContainer}>
        {/* Tabs */}
        <View style={styles.tabContainer}>
          <TouchableOpacity>
            <Text style={[styles.tab, styles.activeTab]}>Today</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={styles.tab}>Weekly</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={styles.tab}>Monthly</Text>
          </TouchableOpacity>
        </View>

        {/* Line Chart */}
        <LineChart
          data={{
            labels: ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'],
            datasets: [
              {
                data: [3000, 5000, 7000, 11000, 8000, 9000, 10000],
              },
            ],
          }}
          width={screenWidth - 40} // Adjust for padding
          height={200}
          chartConfig={chartConfig}
          bezier
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  achievement: {
    fontSize: 16,
    textAlign: 'center',
    marginVertical: 10,
  },
  highlight: {
    color: '#2252DE',
    fontWeight: 'bold',
  },
  progressContainer: {
    alignItems: 'center',
    marginVertical: 20,
    position: 'relative',
    padding: 5,
  },
  centerContent: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  stepCount: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  stepGoal: {
    fontSize: 14,
    textAlign: 'center',
    color: '#888',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 10,
  },
  metric: {
    alignItems: 'center',
    position: 'relative',
  },
  metricContent: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 80, // Match circle size
    height: 80,
  },
  metricValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2252DE',
  },
  metricLabel: {
    fontSize: 10,
    color: '#888',
  },
  chartContainer: {
    marginTop: 20,
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 10,
  },
  tab: {
    fontSize: 14,
    color: '#888',
  },
  activeTab: {
    color: '#2252DE',
    fontWeight: 'bold',
  },
});

export default StepsScreen;
