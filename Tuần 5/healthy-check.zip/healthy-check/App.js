import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HealthJourneyScreen from './HealthJourneyScreen'; // Màn hình hiện tại
import LoginScreen from './LoginScreen'; // Màn hình tiếp theo
import NextScreen from './NextScreen';
import AllHealthData from './AllHealthData'
import StepsScreen from './StepsScreen';
import SleepScreen from './SleepScreen';
import CycleTrackingScreen from './CycleTrackingScreen';
import Nutrition from './Nutrition';
import Explore from './Explore';
import Sharing from './Sharing';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="HealthJourneyScreen">
        <Stack.Screen 
          name="HealthJourney" 
          component={HealthJourneyScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="LoginScreen" 
          component={LoginScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="NextScreen" 
          component={NextScreen}
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="AllHealthData" 
          component={AllHealthData}
          options={{ title: 'All Health Data',headerTitleAlign: 'center',}}
        />
        <Stack.Screen 
          name="Steps" 
          component={StepsScreen} 
          options={{ 
            title: 'Steps',
            headerTitleAlign: 'center',  // Căn giữa tiêu đề của màn hình Steps
          }} 
        />
        <Stack.Screen name="Sleep" component={SleepScreen} options={{ title: 'Sleep',headerTitleAlign: 'center',}} />
        <Stack.Screen 
          name="CycleTracking" 
          component={CycleTrackingScreen} 
          options={{ title: 'Cycle Tracking',headerTitleAlign: 'center',}}
        />
        <Stack.Screen 
          name="Nutrition" 
          component={Nutrition} 
          options={{ title: 'Nutrition',headerTitleAlign: 'center', }} 
        />
        <Stack.Screen 
          name="Explore" 
          component={Explore} 
          options={{ headerShown: false  }} 
        />
        <Stack.Screen 
          name="Sharing" 
          component={Sharing} 
          options={{ headerShown: false  }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
