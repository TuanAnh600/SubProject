import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function App() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.text}>You have consumed</Text>
        <Text style={styles.text}>
          <Text style={styles.text1}>960 kcal</Text>{' '}
          <Text>today</Text>
        </Text>
      </View>
      <View style={styles.imgbox}>
        <Image source={require('./Image/chart.svg')} style={styles.img}/>
        <Text style={styles.imgtext}>60%</Text>
        <Text style={styles.imgtext1}>at 1300kcal</Text>
      </View>
      <View>
        <View style={styles.nubox}>
          <View style={styles.cobox}>
            <View style={styles.col}></View>
            <Text style={styles.nutext}> Fat</Text>
          </View>
          <Text style={styles.nutext1}>     80g</Text>
          <Text style={styles.nutext1}>40%</Text>
        </View>
        <View style={styles.nubox}>
          <View style={styles.cobox}>
            <View style={styles.col1}></View>
            <Text style={styles.nutext}> Protein</Text>
          </View>
          <Text style={styles.nutext1}>160g</Text>
          <Text style={styles.nutext1}>62%</Text>
        </View>
        <View style={styles.nubox}>
          <View style={styles.cobox}>
            <View style={styles.col2}></View>
            <Text style={styles.nutext}> Carbs</Text>
          </View>
          <Text style={styles.nutext1}>   230g</Text>
          <Text style={styles.nutext1}>56%</Text>
        </View>
      </View>
      <View>
        <TouchableOpacity style={styles.btn}>
          <View style={styles.btnview}>
            <Ionicons name="fast-food-outline" style={styles.btntext}/>  
            <Text style={styles.btntext}> Add meals</Text>  
          </View>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white', // Set the background color to white
  },
  header: {
    marginTop: 20,
    marginBottom: 30,
    alignItems: 'center',
    padding: 1,
  },
  text:{
    fontSize: 24,
    fontWeight: 600,
  },
  text1:{
    fontSize: 24,
    fontWeight: 600,
    color: '#555CE0'
  },
  imgbox:{
    alignItems: 'center',
    position: 'relative',
    marginBottom: 40,
  },
  imgtext:{
    position: 'absolute',
    top: 90,
    fontSize: 29,
    fontWeight: '600'
  }, 
  imgtext1:{
    position: 'absolute',
    top: 135,
    fontSize: 14,
    fontWeight: '400',
    color: '#9095A0FF'
  }, 
  nubox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 30,
    borderWidth: 1,
    padding: 5,
    borderColor: '#f7f7f7',
    borderRadius: 10,
    marginVertical: 5,
  },
  cobox:{
    flexDirection: 'row'
  },
  col:{
    backgroundColor: '#7ed8db',
    width: 24,
    height: 24,
    borderRadius: 50,
  },
  col1:{
    backgroundColor: '#9374d1',
    width: 24,
    height: 24,
    borderRadius: 50,
  },
  col2:{
    backgroundColor: '#7d83e6',
    width: 24,
    height: 24,
    borderRadius: 50,
  },
  nutext: {
    fontWeight: '400',
    fontSize: 15,
  },
  nutext1: {
    fontWeight: '600',
    fontSize: 15,
  },
  btnview:{
    flexDirection: 'row',
    alignItems: 'center'
  },
  btn:{
    backgroundColor: '#535CE8FF',
    padding: 10,
    marginHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    marginTop: 20,
  }, 
  btntext:{
    fontSize: 16,
    color: 'white',
  },
});
