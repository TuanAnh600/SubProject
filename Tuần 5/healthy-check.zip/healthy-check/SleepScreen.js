import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { BarChart } from 'react-native-chart-kit';

const { width } = Dimensions.get('window');

const SleepScreen = () => {
  const chartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [{ data: [5, 6.5, 7, 6, 6.8, 8, 7.2] }],
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.subTitle}>
          Your average time of sleep a day is{' '}
          <Text style={styles.highlight}>7h 31 min</Text>
        </Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity style={styles.tab}>
          <Text style={styles.tabText}>Today</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, styles.activeTab]}>
          <Text style={[styles.tabText, styles.activeText]}>Weekly</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tab}>
          <Text style={styles.tabText}>Monthly</Text>
        </TouchableOpacity>
      </View>

      {/* Bar Chart */}
      <View style={styles.chartContainer}>
        <BarChart
          data={chartData}
          width={width - 40} // Adjust width dynamically to fit within the container
          height={200}
          yAxisSuffix="h"
          fromZero={true} // Ensures the chart starts from zero
          withInnerLines={false} // Removes excess inner gridlines
          chartConfig={{
            backgroundGradientFrom: '#F6F8FD',
            backgroundGradientTo: '#F6F8FD',
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(122, 93, 237, ${opacity})`,
            labelColor: () => '#A5A5A5',
            barPercentage: 0.6, // Adjust bar size
          }}
          style={styles.chart}
        />
      </View>

      {/* Statistics */}
      <View style={styles.statsContainer}>
        <View style={[styles.statCard, styles.shadow]}>
          <Text style={styles.statTitle}>🌟 Sleep rate</Text>
          <Text style={styles.statValue}>82%</Text>
        </View>
        <View style={[styles.statCard, styles.shadow]}>
          <Text style={styles.statTitle}>🎉 Deep sleep</Text>
          <Text style={styles.statValue}>1h 3min</Text>
        </View>
      </View>

      {/* Schedule Section */}
      <View style={styles.scheduleHeader}>
  <Text style={styles.scheduleTitle}>Set your schedule</Text>
  <TouchableOpacity style={styles.editButton}>
    <Text style={styles.editText}>Edit</Text>
  </TouchableOpacity>
</View>
<View style={styles.scheduleRow}>
  <View style={[styles.scheduleCard, styles.shadow]}>
    <Text style={styles.scheduleLabel}>Bedtime</Text>
    <Text style={styles.scheduleTime}>22:00 pm</Text>
  </View>
  <View style={[styles.scheduleCard, styles.shadow]}>
    <Text style={styles.scheduleLabel}>Wake up</Text>
    <Text style={styles.scheduleTime}>07:30 am</Text>
  </View>
</View>

    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { backgroundColor: 'white', padding: 20, paddingBottom: 50 },
  header: { marginBottom: 30 },
  subTitle: { fontSize: 16, marginTop: 5, color: '#555' },
  highlight: { color: '#7A5DED', fontWeight: 'bold' },
  tabs: { flexDirection: 'row', marginBottom: 20, justifyContent: 'center' },
  tab: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    backgroundColor: '#E8E3FF',
    marginHorizontal: 5,
  },
  activeTab: { backgroundColor: '#7A5DED' },
  tabText: { fontSize: 14, color: '#555' },
  activeText: { color: '#FFF', fontWeight: '700' },
  chartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 10,
    marginBottom: 30,
    overflow: 'hidden', // Ensures content stays within bounds
  },
  chart: {
    borderRadius: 10,
  },
  statsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 },
  statCard: {
    flex: 1,
    backgroundColor: '#FFF',
    padding: 20,
    marginHorizontal: 5,
    borderRadius: 15,
    alignItems: 'center',
  },
  statTitle: { fontSize: 14, color: '#888', marginBottom: 5 },
  statValue: { fontSize: 18, fontWeight: '700', color: '#333' },
  scheduleTitle: { fontSize: 18, fontWeight: '700', color: '#333', marginBottom: 15 },
  scheduleRow: { flexDirection: 'row', justifyContent: 'space-between' },
  scheduleCard: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFF',
    marginHorizontal: 5,
    borderRadius: 15,
    alignItems: 'center',
  },
  scheduleLabel: { fontSize: 14, color: '#888' },
  scheduleTime: { fontSize: 16, fontWeight: '700', color: '#333', marginTop: 5 },
  editButton: { alignSelf: 'flex-end', marginTop: 20 },
  editText: { fontSize: 16, color: '#7A5DED', fontWeight: '700' },
  shadow: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  scheduleHeader: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: 15,
},
editButton: {
  paddingHorizontal: 10,
  paddingVertical: 5,
  backgroundColor: '#7A5DED',
  borderRadius: 5,
},
editText: {
  fontSize: 14,
  color: '#FFF',
  fontWeight: '700',
},
});

export default SleepScreen;
