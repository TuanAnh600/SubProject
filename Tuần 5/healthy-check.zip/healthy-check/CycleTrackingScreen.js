import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
const { width } = Dimensions.get('window');

export default function CycleTrackingScreen() {
  return (
    <ScrollView
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={true} // Show scroll bar
    >
      {/* Date Selector */}
      <View style={styles.dateSelector}>
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, index) => (
          <View key={index} style={styles.dateItem}>
            <Text style={styles.dayText}>{day}</Text>
            <Text style={styles.dateText}>{6 + index}</Text>
          </View>
        ))}
      </View>

      {/* Period Countdown */}
      <View style={styles.countdownContainer}>
        <Text style={styles.countdownTitle}>Period in</Text>
        <Text style={styles.countdownDays}>12 days</Text>
        <Text style={styles.countdownSubtitle}>Low chance of getting pregnant</Text>
        <TouchableOpacity style={styles.editButton}>
          <Text style={styles.editButtonText}>Edit period dates</Text>
        </TouchableOpacity>
      </View>

      {/* Feeling Today Section */}
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>How are you feeling today?</Text>
        <View style={styles.feelingOptions}>
          <TouchableOpacity style={styles.feelingOption}>
            <Text style={styles.feelingText}>Share your symptoms with us</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.feelingOption}>
            <Text style={styles.feelingText}>Here’s your daily insights</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Menstrual Health Section */}
      <View style={styles.blogsContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Menstrual Health</Text>
          <Text style={styles.linkText}>View more  ></Text>
      </View>
      <ScrollView 
        horizontal={true}            
        contentContainerStyle={styles.blogCards} > 
      <View style={styles.blogCard}>
        <Image source={require('./Image/blog2.jpg')} style={styles.blogImage} />
        <Text style={styles.blogTitle}>Craving sweets on your period? Here's why & what to do</Text>
        <View style={styles.blogre}>
          <View style={styles.blogTag}>
            <Ionicons name="thumbs-up-outline" style={styles.tagtext}/>
            <Text style={styles.tagtext}>78 votes</Text>
          </View>
          <TouchableOpacity>
            <Text style={{color: '#9095A0FF'}}>Tell me more  ></Text>  
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.blogCard}>
        <Image source={require('./Image/images.png')} style={styles.blogImage} />
        <Text style={styles.blogTitle}>Is birth control pills bad for your menstrual health?</Text>
        <View style={styles.blogre}>
          <View style={styles.blogTag}>
            <Ionicons name="thumbs-up-outline" style={styles.tagtext}/>
            <Text style={styles.tagtext}>54votes</Text>
          </View>
          <TouchableOpacity>
            <Text style={{color: '#9095A0FF'}}>Tell me more  ></Text>  
          </TouchableOpacity>
        </View>
      </View>
      </ScrollView>
    </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
    flexGrow: 1, // Ensures the ScrollView takes the full available space
  },
  dateSelector: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 20,
  },
  dateItem: {
    alignItems: 'center',
  },
  dayText: {
    color: '#888',
    fontSize: 12,
  },
  dateText: {
    color: '#333',
    fontSize: 16,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
  },
  countdownContainer: {
    alignItems: 'center',
    marginVertical: 20,
    padding: 20,
    borderRadius: 100,
    backgroundColor: '#d4c7f9',
  },
  countdownTitle: {
    fontSize: 18,
    color: '#fff',
  },
  countdownDays: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#fff',
  },
  countdownSubtitle: {
    fontSize: 14,
    color: '#eee',
    marginBottom: 10,
  },
  editButton: {
    backgroundColor: '#fff',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  editButtonText: {
    color: '#7a52c0',
    fontWeight: '600',
  },
  sectionContainer: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  feelingOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  feelingOption: {
    width: (width - 50) / 2,
    backgroundColor: '#f0f0f0',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  feelingText: {
    fontSize: 14,
    textAlign: 'center',
  },
  blogsContainer: { 
    marginTop: 20 
  },
  blogCards: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginTop: 10 
  },
  blogCard: { 
    width: 272,
    height: 340, 
    marginRight: 16,
    borderRadius: 10, 
    backgroundColor: '#ffffff', 
    padding: 10
  },
  blogImage: { 
    width: 230,
    height: 162,
    marginTop: 10,
    marginHorizontal: 11,
    borderRadius: 16,
    marginBottom: 10
  },
  blogre: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  blogTitle: { 
    fontSize: 18, 
    fontWeight: '600', 
    marginTop: 5,
    marginBottom: 20
  },
  blogTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#CACDF8FF',
    borderRadius: 10,
    marginLeft: 11,
    padding: 5
  },
  tagtext: {
    color: '#555ce0',
    marginHorizontal: 2
  },
  sectionHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center' 
  },
});
