import {View, Text, TextInput, Image, FlatList, StyleSheet, TouchableOpacity, ScrollView} from "react-native";
import { Ionicons } from '@expo/vector-icons';


const App = () => {
  const categories = [
    { id: "1", title: "Nutrition", icon: "🥗" },
    { id: "2", title: "Sports", icon: "🏃" },
    { id: "3", title: "Running", icon: "👟" },
  ];

  const blogs = [
    {
      id: "1",
      category: "Nutrition",
      title: "More about Apples: Benefits, nutrition, and tips",
      votes: 78,
      image: require('./Image/b1.jpg'), 
    },
    {
      id: "2",
      category: "Lifestyle",
      title: "The science of maximizing performance",
      votes: 54,
      image: require('./Image/b2.jpg'), 
    },
  ];

  const renderCategory = ({ item }) => (
    <TouchableOpacity style={styles.categoryContainer}>
      <Text style={styles.categoryIcon}>{item.icon}</Text>
      <Text style={styles.categoryTitle}>{item.title}</Text>
    </TouchableOpacity>
  );

  const renderBlog = ({ item }) => (
    <TouchableOpacity style={styles.blogCard}>
      <Image source={item.image} style={styles.blogImage} />
      <View style={styles.blogContent}>
        <Text style={styles.blogCategory}>{item.category}</Text>
        <Text style={styles.blogTitle}>{item.title}</Text>
        <Text style={styles.blogVotes}>{item.votes} votes</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchBar}>
        <TextInput placeholder="Search topic" style={styles.searchInput} />
        <Image source={require('./Image/A1.jpg')} style={styles.profileImage} />
      </View>

      {/* Categories */}
      <Text style={styles.sectionTitle}>For you</Text>
      <FlatList 
        data={categories} 
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={renderCategory}
      />

      {/* Blogs */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Newest blogs</Text>
        <Text style={styles.viewMore}>View more ></Text>
      </View>
      <FlatList
        data={blogs}
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={renderBlog}
      />

       {/* Menu */}
      <View style={styles.menu}>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="menu-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Overview</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="compass-outline" style={styles.menuicon1}/>
          <Text style={styles.menuitext1}>Explore</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="share-social-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Sharing</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
  },
  searchInput: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 22,
    padding: 10,
    marginRight: 20,
    borderWidth: 1,
    borderColor: '#BCC1CAFF'
  },
  profileImage: {
    backgroundColor: '#CACDF8FF',
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginVertical: 15,
  },
  categoryContainer: {
    alignItems: "center",
    marginRight: 20,
    backgroundColor: '#F1F2FDFF',
    width: 80,
    height: 80,
    justifyContent: 'center',
    borderRadius: 16,
  },
  categoryIcon: {
    fontSize: 25,
  },
  categoryTitle: {
    marginTop: 5,
    fontSize: 14,
    color: "#555",
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  viewMore: {
    color: "#007BFF",
  },
  blogCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    marginRight: 20,
    overflow: "hidden",
    width: 200,
  },
  blogImage: {
    width: "100%",
    height: 100,
  },
  blogContent: {
    padding: 10,
  },
  blogCategory: {
    fontSize: 12,
    color: "#777",
  },
  blogTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginVertical: 5,
  },
  blogVotes: {
    fontSize: 12,
    color: "#777",
  },
  menu: {
    marginTop: 70,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
  },
  menuicon: {
    fontSize: 15,
  },
  menuicon1: {
    fontSize: 15,
    color: '#555ce0'
  },
  menubox: {
    alignItems: 'center',
    marginHorizontal: 12
  },
  menuitext1:{
    color: '#555ce0',
  },
});

export default App;
