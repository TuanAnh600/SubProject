import { Ionicons } from '@expo/vector-icons';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';

export default function SharingScreen() {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Sharing</Text>

        <View style={styles.card}>
          <View style={styles.cardleft}>
            <Image source={require('./Image/bell.svg')}  style={styles.cardimg}/>
          </View>
          <View>
            <Text style={styles.cardTitle}>Keep your health in check</Text>
            <Text style={styles.cardDescription}>Keep loved ones informed about your condition.</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardleft}>
            <Image source={require('./Image/privacy.png')}  style={styles.cardimg}/>
          </View>
          <View>
            <Text style={styles.cardTitle}>Protect your privacy</Text>
            <Text style={styles.cardDescription}>Share key conclusions. Stop anytime.</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardleft}>
            <Image source={require('./Image/list.svg')}  style={styles.cardimg}/>
          </View>
          <View>
            <Text style={styles.cardTitle}>Notifications</Text>
            <Text style={styles.cardDescription}>Get notified of updates to shared dashboards.</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.button} onPress={() => console.log('Start Sharing')}>
          <Ionicons name="share-social-outline" style={styles.buttonText}/>
          <Text style={styles.buttonText}>Start sharing</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingsButton} onPress={() => console.log('Settings')}>
          <Ionicons name="settings-outline" style={styles.settingsText}/>
          <Text style={styles.settingsText}>Setting</Text>
        </TouchableOpacity>

         {/* Menu */}
      <View style={styles.menu}>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="menu-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Overview</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="compass-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Explore</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="share-social-outline" style={styles.menuicon1}/>
          <Text style={styles.menuitext1}>Sharing</Text>
        </TouchableOpacity>
      </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    backgroundColor: '#fafafb',
  },
  content: {
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#333',
  },
  card: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    flexDirection: 'row'
  },
  cardimg:{
    width: 28,
    height: 28,
    resizeMode: 'contain',
    marginRight: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#171A1FFF',
  },
  cardDescription: {
    fontSize: 14,
    color: '#171A1FFF',
    flexWrap: 'wrap', 
    width: 220, 
  },
  button: {
    backgroundColor: '#555ce0',
    paddingVertical: 13,
    borderRadius: 26,
    marginVertical: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 5,
  },
  settingsButton: {
    marginTop: 5,
    alignItems: 'center',
    borderRadius: 26,
    borderWidth: 1,
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  settingsText: {
    fontSize: 16,
    color: '#424955FF',
    marginHorizontal: 5,
  },
  menu: {
    marginTop: 60,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    padding: 10,
  },
  menuicon: {
    fontSize: 20,
  },
  menuicon1: {
    fontSize: 20,
    color: '#555ce0'
  },
  menubox: {
    alignItems: 'center',
    marginHorizontal: 12
  },
  menuitext1:{
    color: '#555ce0',
  },
});
