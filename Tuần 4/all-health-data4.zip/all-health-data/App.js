import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const HealthDataScreen = () => {
  const data = [
    { id: 1, title: 'Double Support Time', value: '29.7 %', icon: '🎯' },
    { id: 2, title: 'Steps', value: '11,875 steps', icon: '👣' },
    { id: 3, title: 'Cycle tracking', value: '08 April', icon: '📅' },
    { id: 4, title: 'Sleep', value: '7 hr 31 min', icon: '🛏️' },
    { id: 5, title: 'Heart', value: '68 BPM', icon: '❤️' },
    { id: 6, title: 'Burned calories', value: '850 kcal', icon: '🔥' },
    { id: 7, title: 'Body mass index', value: '18,69 BMI', icon: '📊' },
  ];

  return (
    <View style={styles.container}>
      <ScrollView>
        <Text style={styles.header}>All Health Data</Text>
        {data.map((item) => (
          <TouchableOpacity key={item.id} style={styles.card}>
            <View style={styles.iconContainer}>
              <Text style={styles.icon}>{item.icon}</Text>
            </View>
            <View style={styles.textContainer}>
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.value}>{item.value}</Text>
            </View>
            <View>
              <Text> ></Text>
            </View>
          </TouchableOpacity>
        ))}

        {/* Menu */}
      <View style={styles.menu}>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="menu-outline" style={styles.menuicon1}/>
          <Text style={styles.menuitext1}>Overview</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="compass-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Explore</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menubox}>
          <Ionicons name="share-social-outline" style={styles.menuicon}/>
          <Text style={styles.menuitext}>Sharing</Text>
        </TouchableOpacity>
      </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 16,
    paddingTop: 40,
  },
  header: {
    fontSize: 20,
    fontWeight: '500',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 10,
    backgroundColor: '#F1F2FDFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  icon: {
    fontSize: 24,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  value: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  menu: {
    marginTop: 31,
    height: 64,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10
  },
  menuicon: {
    fontSize: 24,
  },
  menuicon1: {
    fontSize: 26,
    color: '#555ce0'
  },
  menubox: {
    alignItems: 'center',
    marginHorizontal: 22
  },
  menuitext1:{
    color: '#555ce0',
  },
});

export default HealthDataScreen;
