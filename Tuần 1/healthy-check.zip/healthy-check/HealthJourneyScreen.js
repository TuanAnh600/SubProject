import React from 'react';
import { View, Text, StyleSheet, ImageBackground, TouchableOpacity } from 'react-native';

const HealthJourneyScreen = ({ navigation }) => {
  const handleContinue = () => {
    navigation.navigate('LoginScreen');
  };

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('./assets/image.png')} // Thay thế đường dẫn đúng của ảnh
        style={styles.imageBackground}
        imageStyle={styles.imageStyle}
      >
      </ImageBackground>

      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <View style={styles.icon}></View> {/* Placeholder for icon */}
        </View>
        <Text style={styles.title}>Let's start your health journey today with us!</Text>
        <TouchableOpacity style={styles.button} onPress={handleContinue}>
          <Text style={styles.buttonText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// Các kiểu dáng tương tự như trước đó
const styles = StyleSheet.create({
  // ...
  container: {
    flex: 1,
    backgroundColor: '#00A9DE',
  },
  imageBackground: {
    width: '100%', // Full horizontal width
    height: 450,
    justifyContent: 'flex-start', // Start positioning from the top
    alignItems: 'center',
  },
  imageStyle: {
    borderBottomLeftRadius: 240,
    resizeMode: 'cover',
  },
  iconContainer: {
    width: 50,
    height: 50,
    backgroundColor: '#FFF',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 100, // Add margin to position it properly within the image
    marginBottom: 20,
    marginHorizontal: 20,
  },
  icon: {
    width: 20,
    height: 20,
    backgroundColor: '#00A9DE', // Placeholder color for the icon
    borderRadius: 10,
    marginHorizontal: 20,
  },
  content: {
    alignItems: 'flex-start',
    position: 'absolute', // Positioning to allow the content to overlap the image
    bottom: 30, // Adjust this value to position the content closer to the button
    width: '100%', // Ensure full width
  },
  title: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'flex-start',
    marginHorizontal: 20,
    marginBottom: 20, // Adjusted to reduce space between title and button
  },
  button: {
    backgroundColor: '#FFF',
    paddingVertical: 15,
    paddingHorizontal: 120,
    borderRadius: 25,
    alignSelf: 'center',
  },
  buttonText: {
    color: '#00A9DE',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HealthJourneyScreen;
