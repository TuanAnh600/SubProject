import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons'; // Ensure Expo icons are installed
import axios from 'axios';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setPasswordVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Toggle password visibility
  const togglePasswordVisibility = () => {
    setPasswordVisible(!isPasswordVisible);
  };

  // Handle sign in request
  const handleSignIn = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    setIsLoading(true); // Start loading
    try {
      // MockAPI URL for getting users
      const response = await axios.get('https://672adcd7976a834dd024a60d.mockapi.io/api/v1/users');

      // Find user with matching email and password
      const user = response.data.find((user) => user.email === email && user.password === password);

      if (user) {
        // If user exists, navigate to NextScreen with email data
        navigation.navigate('NextScreen', { email: user.email });
      } else {
        Alert.alert('Error', 'Invalid email or password');
      }
    } catch (error) {
      console.error('Error during login:', error);
      Alert.alert('Error', 'An error occurred during login');
    } finally {
      setIsLoading(false); // Stop loading
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome back 👋</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter email"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Password</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            style={styles.input}
            placeholder="Enter password"
            secureTextEntry={!isPasswordVisible} // Dynamically toggle secure text entry
            value={password}
            onChangeText={setPassword}
          />
          <Ionicons
            name={isPasswordVisible ? 'eye' : 'eye-off'}
            size={20}
            color="gray"
            style={styles.icon}
            onPress={togglePasswordVisibility}
          />
        </View>
      </View>

      <TouchableOpacity>
        <Text style={styles.forgotPassword}>Forgot password?</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
        <Text style={styles.signInText}>Sign In</Text>
      </TouchableOpacity>

      {isLoading && <ActivityIndicator size="large" color="#00C2FF" />}

      <Text style={styles.orText}>OR LOG IN WITH</Text>

      <View style={styles.socialIconsContainer}>
        <FontAwesome name="google" size={24} color="#EA4335" style={styles.socialIcon} />
        <FontAwesome name="facebook" size={24} color="#3b5998" style={styles.socialIcon} />
        <FontAwesome name="apple" size={24} color="black" style={styles.socialIcon} />
      </View>

      <TouchableOpacity>
        <Text style={styles.signUpText}>
          Don’t have an account? <Text style={styles.signUpLink}>Sign up</Text>
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
  },
  input: {
    height: 50,
    backgroundColor: '#F3F4F6',
    borderRadius: 10,
    paddingHorizontal: 10,
    fontSize: 16,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 10,
    height: 50,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#CCC',
  },
  icon: {
    position: 'absolute',
    right: 10,
  },
  forgotPassword: {
    textAlign: 'right',
    color: '#00A9DE',
    marginBottom: 20,
  },
  signInButton: {
    backgroundColor: '#00C2FF',
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 20,
  },
  signInText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  orText: {
    textAlign: 'center',
    color: '#999',
    marginBottom: 10,
  },
  socialIconsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 30,
  },
  socialIcon: {
    marginHorizontal: 10,
  },
  signUpText: {
    textAlign: 'center',
    color: '#999',
  },
  signUpLink: {
    color: '#00A9DE',
    fontWeight: 'bold',
  },
});

export default LoginScreen;
