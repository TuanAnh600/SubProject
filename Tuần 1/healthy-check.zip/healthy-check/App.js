import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HealthJourneyScreen from './HealthJourneyScreen'; // Màn hình hiện tại
import LoginScreen from './LoginScreen'; // Màn hình tiếp theo
import NextScreen from './NextScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="HealthJourney">
        <Stack.Screen 
          name="HealthJourney" 
          component={HealthJourneyScreen} 
          options={{ headerShown: false }} // Ẩn tiêu đề của màn hình
        />
        <Stack.Screen 
          name="LoginScreen" 
          component={LoginScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="NextScreen" 
          component={NextScreen}
          options={{ headerShown: false }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
